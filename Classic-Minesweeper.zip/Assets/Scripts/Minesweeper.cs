﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Object[] sprites = Resources.LoadAll("SmallButton");
        sprRen.sprite = sprites[52] as Sprite;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
