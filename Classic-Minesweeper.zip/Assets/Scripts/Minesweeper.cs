﻿using UnityEngine;

public class Minesweeper : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        int[][] grid = new int[9][9];
        System.Random r = new System.Random();
        int ten, one, mine;
        for(int i = 0; i < 10; i++) {
            mine = r.Next(1,99);
            ten = mine / 10;
            one = mine % 10;
            System.Diagnostics.Debug.WriteLine("%d %d", ten, one);
            grid[ten][one] = 1;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
